<HTML>
<head>
<title>ycam/8090</title>

<xscript src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></xscript>
<script src="static/jquery.min.js"></script>
<style>
  td  { padding: 5px; }
  table, th, td {
    bborder: 1px solid black;
    border-collapse: collapse;
  }
  .B {
           color: #0a0000;
           background-color: #aaf3bc;
           font-size: 13px;
           border: 1px solid #2d63c8;
           padding: 5px 5px;
           cursor: pointer;
           width: 90px;
           height: 28px;
           border-radius: 9px;
   }
   .B:hover {
           color: #2d63c8;
           background-color: #68ee9b;
   }
</style>

<script>
$(document).ready(function(){
  $("#bcamLocalUtilTemp").click(function(){
      $.get("http://192.168.1.134/bc/bcamUTILwrapper.php", function(data, status){
      myObj = JSON.parse(data)
      $("#bcamTemp2").text(myObj.temp )
      $("#bcamUtil2").text(myObj.util )
      $("#bcamHostname2").text(myObj.hostname )
      $("#msgLocalUTILTemp").text(data)
      console.log("bLUTcb: ts="+myObj.timestamp)
      });
  });

  $("#bcamUtilTemp").click(function(){  // returns "bcamUTILcallback("+cpuj+")"
    let s = document.createElement("script");
    s.src = "http://192.168.1.29:8080/UTIL"
    document.body.appendChild(s);
    document.body.removeChild(s);$("#bcamLocalUTILTemp").click(); 
  });

  $("#bcamPID").click(function(){   // returns "bcamPIDcallback("+cpuj+")"
    let s = document.createElement("script");
    s.src = "http://192.168.1.29:8080/PID"
    document.body.appendChild(s);
    document.body.removeChild(s);
  });

  $("#StopCamera").click(function(){  
    $xget('K')       // $xget is OK for now, just used to stop camera
  });

  //---------------------------- --------
  $("#BL").click(function(){
    $("#servomsg").html("BL");
    commandSERVO('BL')
  });

  $("#BC").click(function(){
    $("#servomsg").html("BC");
    commandSERVO('BC')
  });

  $("#BR").click(function(){
    $("#servomsg").html("BR"); 
    commandSERVO('BR')
  });

  $("#BPL").click(function(){
    $("#servomsg").html("BPL");
    commandSERVO('BPL')
  });

  $("#BPS").click(function(){
    $("#servomsg").html("BPS");
    commandSERVO('BPS')
  });

  $("#BPR").click(function(){
    $("#servomsg").html("BPR");
    commandSERVO('BPR')
  });
  //---------------------------- --------

  $("#CBred").click(function(){
    if ( $(this).prop('checked') ) {
       $("#LEDmsg").html("red on");
       commandLED("R")
    } else {
       $("#LEDmsg").html("red off");
       commandLED("r")
    }
  });

  $("#CByellow").click(function(){
    if ( $(this).prop('checked') ) {
       $("#LEDmsg").html("yellow on");
       commandLED("Y")
    } else { 
       $("#LEDmsg").html("yellow off");
       commandLED("y")
    }
  });

  $("#CBblue").click(function(){
    if ( $(this).prop('checked') ) {
       $("#LEDmsg").html("blue on");
       commandLED("B")
    } else {
       $("#LEDmsg").html("blue off"); 
       commandLED("b")
    }
  });

  $("#LEDreset").click(function(){
     $("#CBred").prop('checked', false);    commandLED("r");
     $("#CByellow").prop('checked', false); commandLED("y");
     $("#CBblue").prop('checked', false);   commandLED("b");
     $("#LEDmsg").html("reset to off");
  });

// begin (*main*)  
    $("#bcamPID").click()
    $("#BC").click(); $("#BPS").click()  // center and detach servo
    $("#LEDreset").click()               // turn off the LEDs

});  // end .ready

function bcamUTILcallback(myObj) {  
  $("#msgUTIL").text("bcamUTIL: " + JSON.stringify(myObj));
  $("#bcamTemp").text(myObj.temp ) 
  $("#bcamUtil").text(myObj.util ) 
  $("#bcamHostname").text(myObj.hostname ) 
  console.log("bUcb: ts="+myObj.timestamp)
}

function bcamPIDcallback(myObj) {  
  $("#msgPID").text("bcamPID: " + JSON.stringify(myObj));
  $("#bcamwebstreamPID").text(myObj.webstreamPID ) 
  $("#bcamwebcmdPID").text(myObj.webcmdPID ) 
  $("#bcamhostname").text(myObj.hostname ) 
  console.log("bPcb: ts="+myObj.timestamp)
}

function myLED(myObj) {  // webcmd hard-codes a json-trick on led-change 
  console.log("remote cat: " + myObj.name)
  $("#msg").text("remote LED: " + JSON.stringify(myObj) )
}

function commandLED(c) {  // RrYyBb
     console.log("command LED: "+c)
     let s = document.createElement("script");
     //s.src = "http://192.168.1.29:8080/?command="+c;
     s.src = "http://{{IP}}:8080/?command="+c;   
     document.body.appendChild(s);
     document.body.removeChild(s);
     console.log("command LED completed: "+c)
}

function $xget(c) {
  commandLED(c)       // OK for now, just used to stop camera
}

function mySERVO(myObj) {  // webcmd returns a call to this with a JSON string as parameter
  console.log("remote dog: " + myObj.name)
  $("#msg").text("remote SERVO: " + JSON.stringify(myObj) )
  drawBearingGauge(document.getElementById("cBearing"), myObj.value)
}

function commandSERVO(c) {  // fmtanz, change to BL, BC etc
     console.log("command SERVO: "+c)
     let s = document.createElement("script");
     s.src = "http://{{IP}}:8080/?command="+c;   
     document.body.appendChild(s);
     document.body.removeChild(s);
     console.log("command SERVO completed: "+c)
}

// cpu stats auto-pull 
  timerID = 0
  timerCounter = 0;
  timerStop = false
  function perfStartTimer() {
     console.log("start timer.")
     timerStop = false
     timerID = setInterval(myTimer, 2000);
  }
  function perfStopTimer() { 
     clearInterval(timerID); 
     timerStop = true
  }
  function myTimer() {
      console.log("timer " + timerCounter)
      timerCounter = timerCounter + 1
      if (timerCounter%50==0 || timerStop) {
         perfaStopTimer()
         console.log("stop timer.") 
      } else {
         $("#bcamUtilTemp").click()
         $("#bcamLocalUtilTemp").click()
      }
  }

bearng = 0
deltab = 0.2

function advance(canv) {
  if ( bearng>=1 || bearng<=-1) { deltab=-deltab}
  drawBearingGauge(canv,bearng)
  bearng = bearng + deltab
}

function drawBearingGauge(canv,bearing){   // servo bearing is in [-1..1]
  var ctx = canv.getContext("2d");
  ctx.clearRect(0, 0, canv.width, canv.height);
  ctx.strokeStyle = "#00ff00";
  ctx.lineWidth=3;
  ctx.lineCap = "round"; 
  centerx = canv.width / 2
  centery = 80
  radius = 50 
  arrowlength = 65
  ctx.beginPath(); ctx.arc(centerx,centery,radius, -Math.PI, 0 ,false); ctx.stroke();
      console.log("B", bearing)

  ctx.beginPath();
  ctx.moveTo(centerx,centery)
  x = centerx + arrowlength * Math.sin(bearing * Math.PI/2)  // [sic] phase shift
  y = centery - arrowlength * Math.cos(bearing * Math.PI/2)  // [sic]
  console.log("bearing", bearing)
  bearingd = bearing*90 
  ctx.lineTo(x,y);
  ctx.lineWidth=5;
  ctx.strokeStyle = "#ff0000";
  ctx.stroke();    // the arrow
  ctx.font = "15px Georgia";
  ctx.fillText("Bearing:  " + bearingd.toFixed(2) + "'", 10, 105);
  ctx.stroke()
}

</script>
</head>
<body>
<H2> Hello, {{param}} from {{IP}} port {{PORT}} </H2>

<table  border=1 width=800 height=500>
<TR><TD width=650 height=550 valign=top> {{!V_frame}}
    <TD width=150>
        <table border=1>
          <TR><TD width=150  height=350> {{!B_frame}}
          <TR><TD width=150  height=120 washeight=150> {{!A_frame}}
        </table>

<TR><TD valign=top width=650 height=50 bgcolor=#c0ffee> {{!M_frame}}
    <Td align=middle bgcolor=#fedcba>   <!-- cpustats is in this single TD -->
        {{!C_frame}}
    </Td>                               <!-- cpustats is in this single TD -->
</table>
<BR><BR><BR>
<img src="static/seahorses.jpg" >
<img src="static/cuttlefish.jpg" >
<pre>
To pass HTML/JS as a param unescaped, use { { ! } } This avoids HTML/JS copy/paste.
</pre>
</body>
</HTML>

